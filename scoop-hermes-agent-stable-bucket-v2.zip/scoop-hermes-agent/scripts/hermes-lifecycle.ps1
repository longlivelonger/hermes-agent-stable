# Runtime lifecycle logic embedded into the generated Scoop manifest.
# Keep compatible with Windows PowerShell 5.1.

function Write-HermesStableInfo {
    param([string]$Message)
    Write-Host "[hermes-agent-stable] $Message" -ForegroundColor Cyan
}

function Write-HermesStableWarn {
    param([string]$Message)
    Write-Warning "[hermes-agent-stable] $Message"
}

function Get-HermesStablePaths {
    $hermesHome = if ($env:HERMES_HOME) { $env:HERMES_HOME } else { Join-Path $env:LOCALAPPDATA 'hermes' }
    [pscustomobject]@{
        HermesHome = $hermesHome
        InstallDir = Join-Path $hermesHome 'hermes-agent'
        BackupDir  = Join-Path $env:USERPROFILE 'Hermes Backups'
        StateDir   = Join-Path $env:LOCALAPPDATA 'HermesAgentStable'
    }
}

function Get-HermesStableCommand {
    param([Parameter(Mandatory = $true)]$Paths)

    # Prefer the managed Hermes instance. PATH is only a last-resort fallback.
    $candidates = @(
        (Join-Path $Paths.HermesHome 'bin\hermes.exe'),
        (Join-Path $Paths.HermesHome 'bin\hermes.cmd'),
        (Join-Path $Paths.InstallDir 'venv\Scripts\hermes.exe')
    )
    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath $candidate -PathType Leaf) { return $candidate }
    }

    $cmd = Get-Command hermes -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($cmd -and $cmd.Source) { return $cmd.Source }
    return $null
}

function Invoke-HermesStableCommand {
    param(
        [Parameter(Mandatory = $true)][string]$HermesCommand,
        [Parameter(Mandatory = $true)][string[]]$Arguments,
        [switch]$Echo
    )

    if ($Echo) { Write-HermesStableInfo ("hermes " + ($Arguments -join ' ')) }
    $previousEap = $ErrorActionPreference
    $previousHermesHome = $env:HERMES_HOME
    try {
        $ErrorActionPreference = 'Continue'
        if ($script:HermesStableHome) { $env:HERMES_HOME = $script:HermesStableHome }
        $global:LASTEXITCODE = 0
        $output = & $HermesCommand @Arguments 2>&1
        $invocationSucceeded = $?
        $exitCode = $LASTEXITCODE
        if ($null -eq $exitCode) { $exitCode = if ($invocationSucceeded) { 0 } else { 1 } }
    } finally {
        if ($null -eq $previousHermesHome) { Remove-Item Env:HERMES_HOME -ErrorAction SilentlyContinue } else { $env:HERMES_HOME = $previousHermesHome }
        $ErrorActionPreference = $previousEap
    }
    [pscustomobject]@{
        ExitCode = [int]$exitCode
        Output   = @($output | ForEach-Object { "$_" })
    }
}

function Get-HermesStableGit {
    param([Parameter(Mandatory = $true)]$Paths)

    # Prefer Git managed by the same Hermes home before global PATH.
    foreach ($candidate in @(
        (Join-Path $Paths.HermesHome 'git\cmd\git.exe'),
        (Join-Path $Paths.HermesHome 'git\bin\git.exe')
    )) {
        if (Test-Path -LiteralPath $candidate -PathType Leaf) { return $candidate }
    }
    $cmd = Get-Command git -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($cmd -and $cmd.Source) { return $cmd.Source }
    return $null
}

function Invoke-HermesStableGit {
    param(
        [Parameter(Mandatory = $true)][string]$Git,
        [Parameter(Mandatory = $true)][string]$InstallDir,
        [Parameter(Mandatory = $true)][string[]]$Arguments
    )
    $previousEap = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        $global:LASTEXITCODE = 0
        $output = & $Git -C $InstallDir @Arguments 2>$null
        $exitCode = $LASTEXITCODE
    } finally {
        $ErrorActionPreference = $previousEap
    }
    [pscustomobject]@{
        ExitCode = [int]$exitCode
        Output = (@($output) -join "`n").Trim()
    }
}

function Get-HermesStableCheckoutInfo {
    param([Parameter(Mandatory = $true)]$Paths)

    $result = [ordered]@{
        IsGitCheckout = $false
        GitAvailable = $false
        RevisionKnown = $false
        StatusKnown = $false
        Tag = $null
        Commit = $null
        Dirty = $false
    }
    if (-not (Test-Path -LiteralPath (Join-Path $Paths.InstallDir '.git'))) { return [pscustomobject]$result }
    $result.IsGitCheckout = $true
    $git = Get-HermesStableGit -Paths $Paths
    if (-not $git) { return [pscustomobject]$result }
    $result.GitAvailable = $true

    $commit = Invoke-HermesStableGit -Git $git -InstallDir $Paths.InstallDir -Arguments @('rev-parse', 'HEAD')
    if ($commit.ExitCode -eq 0 -and $commit.Output -match '^[0-9a-fA-F]{40,64}$') {
        $result.Commit = $commit.Output.Trim().ToLowerInvariant()
        $result.RevisionKnown = $true
    }

    $tag = Invoke-HermesStableGit -Git $git -InstallDir $Paths.InstallDir -Arguments @('describe', '--tags', '--exact-match', 'HEAD')
    if ($tag.ExitCode -eq 0 -and $tag.Output) { $result.Tag = $tag.Output.Trim() }

    $status = Invoke-HermesStableGit -Git $git -InstallDir $Paths.InstallDir -Arguments @('status', '--porcelain')
    if ($status.ExitCode -eq 0) {
        $result.StatusKnown = $true
        if ($status.Output) { $result.Dirty = $true }
    }
    return [pscustomobject]$result
}

function ConvertFrom-HermesStableGatewayListOutput {
    param(
        [string[]]$Lines = @(),
        [bool]$Multiplex = $false
    )

    $profiles = New-Object System.Collections.Generic.List[string]
    foreach ($line in $Lines) {
        if ($line -notmatch '\bPID\s+\d+\b') { continue }
        $clean = $line -replace '\x1B\[[0-?]*[ -/]*[@-~]', ''
        $clean = $clean -replace '^\s*[^A-Za-z0-9_-]+', ''
        if ($clean -match '^(?<name>[A-Za-z0-9_-]+)(?:\s+\(current\))?.*\bPID\s+\d+\b') {
            $name = $Matches['name']
            if ($Multiplex -and $name -ne 'default') { continue }
            if (-not $profiles.Contains($name)) { $profiles.Add($name) }
        }
    }
    return @($profiles)
}

function Get-HermesStableRunningGateways {
    param([Parameter(Mandatory = $true)][string]$HermesCommand)

    $multiplex = $false
    foreach ($key in @('gateway.multiplex_profiles', 'multiplex_profiles')) {
        $multiplexResult = Invoke-HermesStableCommand -HermesCommand $HermesCommand -Arguments @('config', 'get', $key, '--json')
        if ($multiplexResult.ExitCode -eq 0) {
            $raw = ($multiplexResult.Output -join '').Trim().ToLowerInvariant()
            if ($raw -eq 'true') { $multiplex = $true; break }
        }
    }

    # Upstream currently documents human-readable `gateway list`, not a stable JSON contract.
    # Keep parsing isolated and fixture-tested so format changes fail predictably.
    $listResult = Invoke-HermesStableCommand -HermesCommand $HermesCommand -Arguments @('gateway', 'list')
    if ($listResult.ExitCode -ne 0) {
        Write-HermesStableWarn 'Could not snapshot gateway state; gateways will not be auto-restarted.'
        return @()
    }
    return @(ConvertFrom-HermesStableGatewayListOutput -Lines $listResult.Output -Multiplex $multiplex)
}

function Stop-HermesStableGateways {
    param(
        [Parameter(Mandatory = $true)][string]$HermesCommand,
        [string[]]$PreviouslyRunning = @()
    )
    $result = Invoke-HermesStableCommand -HermesCommand $HermesCommand -Arguments @('gateway', 'stop', '--all') -Echo
    if ($result.ExitCode -ne 0 -and $PreviouslyRunning.Count -gt 0) {
        throw "Failed to stop running Hermes gateways (exit $($result.ExitCode))."
    }
}

function Start-HermesStableGateways {
    param(
        [Parameter(Mandatory = $true)][string]$HermesCommand,
        [string[]]$Profiles = @()
    )
    $failures = New-Object System.Collections.Generic.List[string]
    foreach ($profile in $Profiles) {
        $args = if ($profile -eq 'default') { @('gateway', 'start') } else { @('-p', $profile, 'gateway', 'start') }
        $result = Invoke-HermesStableCommand -HermesCommand $HermesCommand -Arguments $args -Echo
        if ($result.ExitCode -ne 0) { $failures.Add($profile) }
    }
    return @($failures)
}

function Get-HermesStableBlockingProcesses {
    param([Parameter(Mandatory = $true)][string]$InstallDir)

    $normalized = [IO.Path]::GetFullPath($InstallDir).TrimEnd('\')
    $matches = New-Object System.Collections.Generic.List[object]
    try {
        foreach ($proc in (Get-CimInstance Win32_Process -ErrorAction Stop)) {
            if ($proc.ProcessId -eq $PID) { continue }
            $exe = "$($proc.ExecutablePath)"
            $cmd = "$($proc.CommandLine)"
            $owned = $false
            if ($exe) {
                try {
                    $fullExe = [IO.Path]::GetFullPath($exe)
                    if ($fullExe.StartsWith($normalized, [StringComparison]::OrdinalIgnoreCase)) { $owned = $true }
                } catch { }
            }
            if (-not $owned -and $cmd -and $cmd.IndexOf($normalized, [StringComparison]::OrdinalIgnoreCase) -ge 0) { $owned = $true }
            if ($owned) {
                $matches.Add([pscustomobject]@{ Id = $proc.ProcessId; Name = $proc.Name; ExecutablePath = $exe })
            }
        }
    } catch {
        Write-HermesStableWarn "Could not inspect Windows processes: $($_.Exception.Message)"
    }
    return @($matches)
}

function Assert-HermesStableNoBlockers {
    param([Parameter(Mandatory = $true)][string]$InstallDir)

    for ($i = 0; $i -lt 5; $i++) {
        $blockers = @(Get-HermesStableBlockingProcesses -InstallDir $InstallDir)
        if ($blockers.Count -eq 0) { return }
        Start-Sleep -Seconds 2
    }
    $blockers = @(Get-HermesStableBlockingProcesses -InstallDir $InstallDir)
    if ($blockers.Count -gt 0) {
        $summary = ($blockers | ForEach-Object { "$($_.Name) (PID $($_.Id))" }) -join ', '
        throw "Hermes-owned processes are still using the install directory: $summary. Close Hermes Desktop/remaining Hermes runtimes and retry."
    }
}

function Test-HermesStableBackupArchive {
    param([Parameter(Mandatory = $true)][string]$Path)

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $false }
    $item = Get-Item -LiteralPath $Path -ErrorAction Stop
    if ($item.Length -le 22) { return $false }
    try {
        Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction SilentlyContinue
        $zip = [System.IO.Compression.ZipFile]::OpenRead($Path)
        try { return ($zip.Entries.Count -gt 0) } finally { $zip.Dispose() }
    } catch {
        Write-HermesStableWarn "Backup archive validation failed: $($_.Exception.Message)"
        return $false
    }
}

function Get-HermesStableBackupRetention {
    $keep = 5
    if (-not [string]::IsNullOrWhiteSpace($env:HERMES_STABLE_BACKUP_KEEP)) {
        $parsed = 0
        $parsedOk = [int]::TryParse($env:HERMES_STABLE_BACKUP_KEEP, [ref]$parsed)
        if (-not $parsedOk -or $parsed -lt 0) {
            throw 'HERMES_STABLE_BACKUP_KEEP must be a non-negative 32-bit integer.'
        }
        $keep = $parsed
    }
    return $keep
}

function New-HermesStableBackup {
    param(
        [Parameter(Mandatory = $true)][string]$HermesCommand,
        [Parameter(Mandatory = $true)]$Paths,
        [string]$OldTag,
        [Parameter(Mandatory = $true)][string]$OldCommit,
        [Parameter(Mandatory = $true)][string]$TargetTag
    )

    New-Item -ItemType Directory -Force -Path $Paths.BackupDir | Out-Null
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $from = if ($OldTag) { $OldTag } else { 'commit-' + $OldCommit.Substring(0, [Math]::Min(12, $OldCommit.Length)) }
    $safeFrom = $from -replace '[^A-Za-z0-9._-]', '_'
    $safeTo = $TargetTag -replace '[^A-Za-z0-9._-]', '_'
    $backupPath = Join-Path $Paths.BackupDir "hermes-agent-stable-preupdate-$stamp-from-$safeFrom-to-$safeTo.zip"

    Write-HermesStableInfo "Creating full backup: $backupPath"
    $result = Invoke-HermesStableCommand -HermesCommand $HermesCommand -Arguments @('backup', '-o', $backupPath) -Echo
    if ($result.ExitCode -ne 0) { throw "Full Hermes backup failed (exit $($result.ExitCode)); update aborted." }
    if (-not (Test-HermesStableBackupArchive -Path $backupPath)) {
        throw 'Hermes backup command returned success but the resulting ZIP is missing, empty, or invalid; update aborted.'
    }

    $keep = Get-HermesStableBackupRetention
    if ($keep -gt 0) {
        $files = @(Get-ChildItem -LiteralPath $Paths.BackupDir -Filter 'hermes-agent-stable-preupdate-*.zip' -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTimeUtc -Descending)
        if ($files.Count -gt $keep) {
            $files | Select-Object -Skip $keep | Remove-Item -Force -ErrorAction SilentlyContinue
        }
    }
    return $backupPath
}

function Write-HermesStableReceipt {
    param(
        [Parameter(Mandatory = $true)]$Paths,
        [Parameter(Mandatory = $true)][hashtable]$Data,
        [string]$Name = 'last-update.json'
    )
    New-Item -ItemType Directory -Force -Path $Paths.StateDir | Out-Null
    $Data['timestampUtc'] = [DateTime]::UtcNow.ToString('o')
    $Data | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $Paths.StateDir $Name) -Encoding UTF8
}

function Invoke-HermesStableDownload {
    param(
        [Parameter(Mandatory = $true)][string]$Uri,
        [Parameter(Mandatory = $true)][string]$OutFile
    )
    $args = @{
        Uri = $Uri
        OutFile = $OutFile
        Headers = @{ 'User-Agent' = 'scoop-hermes-agent-stable' }
        ErrorAction = 'Stop'
    }
    if ($PSVersionTable.PSVersion.Major -lt 6) { $args['UseBasicParsing'] = $true }
    Invoke-WebRequest @args | Out-Null
}

function Test-HermesStableInstallerCommitCapability {
    param([Parameter(Mandatory = $true)][string]$InstallerPath)
    if (-not (Test-Path -LiteralPath $InstallerPath -PathType Leaf)) { return $false }
    try {
        $text = Get-Content -Raw -LiteralPath $InstallerPath -ErrorAction Stop
        return ($text -match '\[string\]\s*\$Commit' -and $text -match '\[switch\]\s*\$ForceCommit')
    } catch {
        return $false
    }
}

function Save-HermesStableRollbackInstaller {
    param(
        [Parameter(Mandatory = $true)]$Paths,
        [Parameter(Mandatory = $true)][string]$OldCommit
    )
    if ($OldCommit -notmatch '^[0-9a-fA-F]{40,64}$') { throw "Invalid rollback commit '$OldCommit'." }
    $commit = $OldCommit.ToLowerInvariant()
    $dir = Join-Path $Paths.StateDir (Join-Path 'rollback-cache' $commit)
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
    $final = Join-Path $dir 'install.ps1'
    $temp = Join-Path $dir ('install-' + [Guid]::NewGuid().ToString('N') + '.tmp')
    $url = "https://raw.githubusercontent.com/NousResearch/hermes-agent/$commit/scripts/install.ps1"
    Write-HermesStableInfo "Prefetching rollback installer from exact old commit $commit"
    try {
        Invoke-HermesStableDownload -Uri $url -OutFile $temp
        if (-not (Test-Path -LiteralPath $temp -PathType Leaf) -or (Get-Item -LiteralPath $temp).Length -lt 100) {
            throw 'Downloaded rollback installer is missing or unexpectedly small.'
        }
        Move-Item -LiteralPath $temp -Destination $final -Force
        Unblock-File -LiteralPath $final -ErrorAction SilentlyContinue
        if (-not (Test-HermesStableInstallerCommitCapability -InstallerPath $final)) {
            throw "Old-commit installer at $commit does not support deterministic -Commit/-ForceCommit rollback."
        }
    } finally {
        Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue
    }
    $hash = (Get-FileHash -LiteralPath $final -Algorithm SHA256).Hash.ToLowerInvariant()
    return [pscustomobject]@{ Path = $final; Sha256 = $hash; Url = $url }
}

function Install-HermesStableCommit {
    param(
        [Parameter(Mandatory = $true)][string]$Installer,
        [Parameter(Mandatory = $true)][string]$Commit,
        [Parameter(Mandatory = $true)]$Paths,
        [string]$Label = 'target'
    )

    if ($Commit -notmatch '^[0-9a-fA-F]{40,64}$') { throw "Invalid $Label commit '$Commit'." }
    Write-HermesStableInfo "Installing Hermes $Label commit $Commit"

    # Run upstream installer in a child Windows PowerShell host. This isolates
    # `exit`/terminating failures from Scoop's lifecycle process and gives us a
    # trustworthy process exit code instead of inheriting the installer's last
    # native-command LASTEXITCODE.
    $powershellExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    if (-not (Test-Path -LiteralPath $powershellExe -PathType Leaf)) {
        $powershellExe = (Get-Command powershell.exe -ErrorAction Stop).Source
    }
    $arguments = @(
        '-NoProfile',
        '-NonInteractive',
        '-ExecutionPolicy', 'Bypass',
        '-File', $Installer,
        '-Commit', $Commit,
        '-ForceCommit',
        '-SkipSetup',
        '-NonInteractive',
        '-HermesHome', $Paths.HermesHome,
        '-InstallDir', $Paths.InstallDir
    )
    $global:LASTEXITCODE = 0
    $output = & $powershellExe @arguments 2>&1
    $exitCode = $LASTEXITCODE
    foreach ($line in @($output)) {
        if ($null -ne $line -and "$line".Length -gt 0) { Write-Host "$line" }
    }
    if ($exitCode -ne 0) {
        throw "Upstream Hermes installer returned failure for $label commit $Commit (exit $exitCode)."
    }
}

function Assert-HermesStableCommit {
    param(
        [Parameter(Mandatory = $true)]$Paths,
        [Parameter(Mandatory = $true)][string]$ExpectedCommit
    )
    $checkout = Get-HermesStableCheckoutInfo -Paths $Paths
    if (-not $checkout.RevisionKnown) { throw 'Could not determine installed Hermes git revision.' }
    if ($checkout.Commit -ne $ExpectedCommit.ToLowerInvariant()) {
        throw "Installed checkout commit '$($checkout.Commit)' does not match expected '$ExpectedCommit'."
    }
    Write-HermesStableInfo "Verified checkout commit: $($checkout.Commit)"
    return $checkout
}

function Assert-HermesStableTarget {
    param(
        [Parameter(Mandatory = $true)]$Paths,
        [Parameter(Mandatory = $true)][string]$HermesCommand,
        [Parameter(Mandatory = $true)][string]$TargetCommit
    )

    $version = Invoke-HermesStableCommand -HermesCommand $HermesCommand -Arguments @('--version') -Echo
    if ($version.ExitCode -ne 0 -or $version.Output.Count -eq 0) {
        throw "Hermes CLI verification failed (exit $($version.ExitCode))."
    }
    $null = Assert-HermesStableCommit -Paths $Paths -ExpectedCommit $TargetCommit
    return ($version.Output -join ' ').Trim()
}

function Restore-HermesStableBackup {
    param(
        [Parameter(Mandatory = $true)]$Paths,
        [string]$BackupPath
    )
    if (-not $BackupPath -or -not (Test-HermesStableBackupArchive -Path $BackupPath)) { return $false }
    $hermes = Get-HermesStableCommand -Paths $Paths
    if (-not $hermes) { return $false }
    Write-HermesStableInfo "Restoring pre-update backup: $BackupPath"
    $result = Invoke-HermesStableCommand -HermesCommand $hermes -Arguments @('import', $BackupPath, '--force') -Echo
    return ($result.ExitCode -eq 0)
}

function Invoke-HermesStableRollback {
    param(
        [Parameter(Mandatory = $true)]$Paths,
        [Parameter(Mandatory = $true)][string]$RollbackInstaller,
        [Parameter(Mandatory = $true)][string]$OldCommit,
        [string]$OldTag,
        [string]$BackupPath,
        [string[]]$RunningGateways = @(),
        [string]$FailureMessage
    )

    Write-HermesStableWarn "Critical update failure: $FailureMessage"
    $hermes = Get-HermesStableCommand -Paths $Paths
    if ($hermes) {
        try { Stop-HermesStableGateways -HermesCommand $hermes -PreviouslyRunning $RunningGateways } catch { Write-HermesStableWarn $_.Exception.Message }
    }

    $codeRollback = $false
    try {
        Install-HermesStableCommit -Installer $RollbackInstaller -Commit $OldCommit -Paths $Paths -Label 'rollback'
        $null = Assert-HermesStableCommit -Paths $Paths -ExpectedCommit $OldCommit
        $codeRollback = $true
    } catch {
        Write-HermesStableWarn "Code rollback failed: $($_.Exception.Message)"
    }

    $dataRollback = $false
    if ($codeRollback) {
        try { $dataRollback = Restore-HermesStableBackup -Paths $Paths -BackupPath $BackupPath } catch { Write-HermesStableWarn "Backup restore failed: $($_.Exception.Message)" }
    }

    $restartFailures = @()
    $hermes = Get-HermesStableCommand -Paths $Paths
    if ($codeRollback -and $dataRollback -and $hermes -and $RunningGateways.Count -gt 0) {
        $restartFailures = @(Start-HermesStableGateways -HermesCommand $hermes -Profiles $RunningGateways)
    } elseif ($RunningGateways.Count -gt 0 -and (-not $codeRollback -or -not $dataRollback)) {
        Write-HermesStableWarn 'Rollback was incomplete; gateways are intentionally left stopped for manual recovery.'
    }

    Write-HermesStableReceipt -Paths $Paths -Name 'last-rollback.json' -Data @{
        status = if ($codeRollback -and $dataRollback) { 'rolled-back' } else { 'rollback-incomplete' }
        failure = $FailureMessage
        oldTag = $OldTag
        oldCommit = $OldCommit
        backup = $BackupPath
        codeRollbackSucceeded = $codeRollback
        dataRollbackSucceeded = $dataRollback
        gatewayRestartFailures = $restartFailures
    }
    Write-HermesStableReceipt -Paths $Paths -Name 'last-attempt.json' -Data @{
        status = if ($codeRollback -and $dataRollback) { 'rolled-back' } else { 'rollback-incomplete' }
        failure = $FailureMessage
        oldTag = $OldTag
        oldCommit = $OldCommit
        backup = $BackupPath
    }
}

function Invoke-HermesStableInstall {
    param(
        [Parameter(Mandatory = $true)][string]$TargetTag,
        [Parameter(Mandatory = $true)][string]$TargetCommit,
        [Parameter(Mandatory = $true)][string]$PackageVersion,
        [Parameter(Mandatory = $true)][string]$UpstreamInstallerPath
    )

    $ErrorActionPreference = 'Stop'
    if ($env:OS -ne 'Windows_NT') { throw 'hermes-agent-stable supports native Windows only.' }
    if ($TargetCommit -notmatch '^[0-9a-fA-F]{40,64}$') { throw "Invalid target commit '$TargetCommit'." }
    $TargetCommit = $TargetCommit.ToLowerInvariant()
    if (-not (Test-Path -LiteralPath $UpstreamInstallerPath -PathType Leaf)) { throw "Pinned upstream installer not found: $UpstreamInstallerPath" }

    $paths = Get-HermesStablePaths
    $script:HermesStableHome = $paths.HermesHome
    New-Item -ItemType Directory -Force -Path $paths.StateDir | Out-Null
    $existingHermes = Get-HermesStableCommand -Paths $paths
    $checkout = Get-HermesStableCheckoutInfo -Paths $paths

    if ($checkout.Dirty) {
        throw "Local source changes detected in '$($paths.InstallDir)'. Commit/stash them manually before using the managed stable package."
    }

    $oldTag = $checkout.Tag
    $oldCommit = $checkout.Commit
    $runningGateways = @()
    $backupPath = $null
    $rollbackInstaller = $null
    $rollbackInstallerHash = $null

    if ($existingHermes) {
        # Existing updates are allowed only when exact rollback state is known.
        $null = Get-HermesStableBackupRetention
        if (-not $checkout.IsGitCheckout -or -not $checkout.GitAvailable -or -not $checkout.RevisionKnown -or -not $checkout.StatusKnown) {
            throw "Existing Hermes was detected, but its exact clean git revision cannot be verified at '$($paths.InstallDir)'. Automatic update is refused because deterministic rollback would not be available."
        }

        $rollback = Save-HermesStableRollbackInstaller -Paths $paths -OldCommit $oldCommit
        $rollbackInstaller = $rollback.Path
        $rollbackInstallerHash = $rollback.Sha256
        $runningGateways = @(Get-HermesStableRunningGateways -HermesCommand $existingHermes)
        $backupPath = New-HermesStableBackup -HermesCommand $existingHermes -Paths $paths -OldTag $oldTag -OldCommit $oldCommit -TargetTag $TargetTag
        try {
            Stop-HermesStableGateways -HermesCommand $existingHermes -PreviouslyRunning $runningGateways
            Assert-HermesStableNoBlockers -InstallDir $paths.InstallDir
        } catch {
            if ($runningGateways.Count -gt 0) {
                $null = Start-HermesStableGateways -HermesCommand $existingHermes -Profiles $runningGateways
            }
            throw
        }
    } else {
        Write-HermesStableInfo 'No existing Hermes CLI detected; performing a fresh non-interactive install (setup remains for the user).'
    }

    Write-HermesStableReceipt -Paths $paths -Name 'last-attempt.json' -Data @{
        status = 'installing'
        packageVersion = $PackageVersion
        targetTag = $TargetTag
        targetCommit = $TargetCommit
        oldTag = $oldTag
        oldCommit = $oldCommit
        backup = $backupPath
        rollbackInstaller = $rollbackInstaller
        rollbackInstallerSha256 = $rollbackInstallerHash
        previouslyRunningGateways = $runningGateways
    }

    try {
        Install-HermesStableCommit -Installer $UpstreamInstallerPath -Commit $TargetCommit -Paths $paths -Label "release $TargetTag"
        $newHermes = Get-HermesStableCommand -Paths $paths
        if (-not $newHermes) { throw 'Hermes CLI was not found after installation.' }
        $versionText = Assert-HermesStableTarget -Paths $paths -HermesCommand $newHermes -TargetCommit $TargetCommit
    } catch {
        $failure = $_.Exception.Message
        if ($existingHermes) {
            Invoke-HermesStableRollback -Paths $paths -RollbackInstaller $rollbackInstaller -OldCommit $oldCommit -OldTag $oldTag -BackupPath $backupPath -RunningGateways $runningGateways -FailureMessage $failure
        } else {
            Write-HermesStableReceipt -Paths $paths -Name 'last-attempt.json' -Data @{
                status = 'failed-fresh-install'
                packageVersion = $PackageVersion
                targetTag = $TargetTag
                targetCommit = $TargetCommit
                failure = $failure
            }
        }
        throw
    }

    $configCheck = Invoke-HermesStableCommand -HermesCommand $newHermes -Arguments @('config', 'check') -Echo
    if ($configCheck.ExitCode -ne 0) {
        Write-HermesStableWarn 'Configuration check reported attention is needed. Run `hermes config migrate` interactively if Hermes recommends it.'
    }

    $doctor = Invoke-HermesStableCommand -HermesCommand $newHermes -Arguments @('doctor') -Echo
    if ($doctor.ExitCode -ne 0) {
        Write-HermesStableWarn "`hermes doctor` reported issues (exit $($doctor.ExitCode)); the exact-commit install itself was verified."
    }

    $restartFailures = @()
    if ($runningGateways.Count -gt 0) {
        $restartFailures = @(Start-HermesStableGateways -HermesCommand $newHermes -Profiles $runningGateways)
        if ($restartFailures.Count -gt 0) {
            Write-HermesStableWarn ("Failed to restart gateway profile(s): " + ($restartFailures -join ', ') + '. Start them manually after reviewing the update.')
        }
    }

    $newCheckout = Get-HermesStableCheckoutInfo -Paths $paths
    $receipt = @{
        status = 'completed'
        packageVersion = $PackageVersion
        targetTag = $TargetTag
        targetCommit = $TargetCommit
        installedCommit = $newCheckout.Commit
        hermesVersionOutput = $versionText
        backup = $backupPath
        configCheckExitCode = $configCheck.ExitCode
        doctorExitCode = $doctor.ExitCode
        previouslyRunningGateways = $runningGateways
        gatewayRestartFailures = $restartFailures
        migrationPolicy = 'interactive-only; run hermes config migrate when needed'
    }
    Write-HermesStableReceipt -Paths $paths -Data $receipt
    Write-HermesStableReceipt -Paths $paths -Name 'last-attempt.json' -Data $receipt

    Write-HermesStableInfo "Installed stable Hermes release $TargetTag @ $TargetCommit."
    if ($configCheck.ExitCode -ne 0) { Write-Host 'Next step if required: hermes config migrate' -ForegroundColor Yellow }
}
